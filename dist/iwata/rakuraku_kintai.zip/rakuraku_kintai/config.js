(() => {
    const key = "kintaro_auto";
    const target = document.getElementsByName("CommuterKind")[0];
    chrome.storage.local.get({[key]: true}, (value) => {
        const isChecked = value[key];
        if(!isChecked || !target) return;
        if(target.selectedIndex) return;
        target.options[2].selected = true;
    });

    const content = document.getElementsByClassName('kinmudatalist')[0];
    chrome.storage.local.set({ workData: {display: false} });
    if(content) {
        // 行番号取得
        const getColNum = (str) => {
            return Array.from(content.querySelector('[data-rowidx="0"]').children).findIndex((th) => {
                const text = th.firstElementChild.textContent;
                return text === str;
            })            
        }
        const num = content.querySelector('[data-rowidx="1"]').children.length === 1 ? 0 : 1
        // 「実働計」の列番号取得
        const timeNum = getColNum('実働計') + num;

        // 「休暇区分」の列番号取得
        const restNum = getColNum('休暇区分') + num;
        
        // 稼働日の「実働計」列を配列に格納
        const tdList = Array.from(content.querySelectorAll(`[data-colidx="${timeNum}"]`)).filter((td) => {
            const day = td.parentNode.children[restNum].firstElementChild.textContent;
            return day.replace( /[\p{C}\p{Z}]/gu, '') === '';
        });

        // 実働計配列を稼働時間（分数）に変換
        const workTimeList = tdList.map((elm) => {
            const convertTime = (timeStr) => {
                const list = timeStr.split(':');
                return parseInt(list[0]) * 60 + parseInt(list[1]);
            }
            const timeStr = elm.firstElementChild.textContent;
            const time = timeStr ? convertTime(timeStr) : 0;
            return time;
        })

        // 稼働時間の合計
        const realWorkTime = workTimeList.reduce((sum, daytime) => {
            return sum + daytime;
        },0);

        // 分数を「時間と分」に変換し配列に格納
        const timeConvert = function (time) {
            if(!time) return {
                hour: 0,
                min:'00'
            }
            const hour = Math.floor(Math.abs(time) / 60);
            const min = Math.abs(time) % 60;
            return {
                hour: hour,
                min:("00" + min).slice(-2)
            }
        }

        const allDay = workTimeList.length;
        const nowDay = workTimeList.filter((time) => time > 0).length
        const necessaryWorkTime = nowDay * 8 * 60;
        const allTime = timeConvert(necessaryWorkTime);
        const nowTime = timeConvert(realWorkTime);
        const gapTime = timeConvert(necessaryWorkTime - realWorkTime);
        const averageTime = nowDay ? timeConvert(Math.floor(realWorkTime/nowDay)) : timeConvert(0)
        const data = {
            allDay,
            nowDay,
            allTime:`${allTime.hour}:${allTime.min}`,
            nowTime: `${nowTime.hour}:${nowTime.min}`,
            averageTime: `${averageTime.hour}:${averageTime.min}`,
            gapTime: `${gapTime.hour}時間${gapTime.min}分`,
            puramai: necessaryWorkTime - realWorkTime > 0, 
            gapDay: allDay - nowDay,
            display: !!content
        }

        chrome.storage.local.set({ workData: data });
    }
})()