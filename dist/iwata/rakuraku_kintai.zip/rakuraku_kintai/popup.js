'use strict';
(()=> {
    const target = document.getElementById("autoSelect");
    const key = "kintaro_auto";
    let isChecked;
    const saveChecked = (value) => {
        chrome.storage.local.set({ [key]: value }, function () {
            console.log("Settings saved", value);
        });
    };
    if (!target) return;
    // 初期設定
    chrome.storage.local.get(key, (value) => {
        const memory = value[key];
        if(memory !== undefined) {
            target.checked = memory;
            isChecked = memory;
        }else {
            target.checked = true;
            isChecked = true;
        }
        saveChecked(isChecked);
    });
    // チェックボックスクリックしたら変更
    target.addEventListener("click", () => {
        saveChecked(target.checked);
    });

    // 勤怠日次一覧ページ
    chrome.storage.local.get('workData', (value) => {
        if(value) {
            const data = value.workData;
            const dataElmList = ['nowDay', 'allTime','nowTime', 'averageTime', 'gapTime', 'gapDay']
            if(!data.display) return;
            
            document.querySelector('#supply').classList.add('is-hidden');
            document.querySelector('#data-list').classList.remove('is-invisible');

            dataElmList.forEach((dataName) => {
                if(dataName === 'gapDay' && data.gapDay === 0) {
                    const target = document.querySelector(`#data-${dataName}`).parentNode;
                    target.innerHTML = 'お勤めご苦労様でした🎉';
                }else {
                    const target = document.querySelector(`#data-${dataName}`);
                    target.innerHTML = data[dataName];
                }
            })
            const puramaiTarget = document.querySelector(`#data-puramai`);
            if(data.puramai) {
                puramaiTarget.classList.add('blue')
                puramaiTarget.innerHTML = '不足'
            } else {
                puramaiTarget.classList.add('red')
                puramaiTarget.innerHTML = '超過'
            }

            const wordTarget = document.querySelector(`#data-word`);
            const getWord = () => {
                const time = data.gapTime.split('時間')[0];
                if(!data.nowDay) {
                    const deleteList = ['averageTime', 'gapTime', 'gapDay', 'puramai'];
                    deleteList.forEach((dataName) => {
                        const target = document.querySelector(`#data-${dataName}`).parentNode;
                        target.classList.add('is-hidden')
                    })
                    return '今月も頑張ろーーうわーい'
                };
                if(data.puramai) return 'もっと働こう。。';
                if(time < 10 ) {
                    return 'いい感じ〜！！！';
                }else if(time < 20) {
                    return 'ほどほどにしてね・・';
                } else if(time < 30) {
                    return 'そろそろ休もう！';
                }
                return '今すぐ寝なさい';
            }
            const wordText = getWord();
            wordTarget.innerHTML = wordText
        }
    });
})()